# stylr-wardrobe-application
This repository contains the machine project for the Mobile Development course.
